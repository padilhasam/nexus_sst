<?php require_once dirname(__DIR__) . '/templates/header.php'; ?>
<div class="mobile-header"><i class="fa-solid fa-arrow-left"></i><span>Agenda</span><i class="fa-regular fa-calendar"></i></div>
<div class="date-filter">01/05/2024 - 31/05/2024 <i class="fa-solid fa-chevron-down"></i></div>
<div class="tabs"><a class="active">Calendário</a><a>Lista</a></div>
<div style="padding:16px">
  <div class="panel"><div style="display:flex;justify-content:space-between;margin-bottom:16px"><i class="fa-solid fa-chevron-left"></i><strong>Maio 2024</strong><i class="fa-solid fa-chevron-right"></i></div>
  <table style="width:100%;text-align:center;font-size:12px;border-collapse:separate;border-spacing:0 12px"><tr><th>Dom</th><th>Seg</th><th>Ter</th><th>Qua</th><th>Qui</th><th>Sex</th><th>Sáb</th></tr><tr><td></td><td></td><td></td><td>1</td><td>2</td><td>3</td><td>4</td></tr><tr><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td><td>11</td></tr><tr><td>12</td><td>13</td><td>14</td><td>15</td><td>16</td><td>17</td><td>18</td></tr><tr><td>19</td><td>20</td><td>21</td><td style="background:#075eea;color:#fff;border-radius:50%">22</td><td>23</td><td>24</td><td>25</td></tr><tr><td>26</td><td>27</td><td>28</td><td>29</td><td>30</td><td>31</td><td></td></tr></table></div>
  <div class="visit-row" style="grid-template-columns:54px 48px 1fr 64px;margin-top:14px"><div class="date-box">22<span>MAI</span></div><div class="time">09:00<br>10:00</div><div><strong>Empresa ABC Ltda</strong><small>Unidade Matriz<br>Padrão</small></div><span class="badge-soft b-blue">Padrão</span></div>
</div>
<?php require_once dirname(__DIR__) . '/templates/footer.php'; ?>
