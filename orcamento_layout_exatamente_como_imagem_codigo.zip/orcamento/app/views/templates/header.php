<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$rotaAtual = trim($_GET['url'] ?? 'dashboard', '/');
$rotaAtual = explode('/', $rotaAtual)[0] ?: 'dashboard';
$usuario = $_SESSION['nome'] ?? 'João Silva';
$pageTitle = [
 'dashboard'=>'Dashboard','agenda'=>'Agenda','visitas'=>'Visitas Técnicas','checklists'=>'Check-list de Visita','quantificacoes'=>'Quantificações','nao_conformidades'=>'Não Conformidades','empresas'=>'Empresas','hierarquias'=>'Hierarquia','riscos'=>'Riscos (GHE)','equipamentos'=>'Equipamentos','mensagens'=>'Mensagens','relatorios'=>'Relatórios','usuarios'=>'Usuários','configuracoes'=>'Configurações'
][$rotaAtual] ?? ucfirst(str_replace('_',' ', $rotaAtual));
function nav_active($r,$atual){ return $r===$atual?'active':''; }
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($pageTitle) ?> | SST</title>
<link rel="icon" href="<?= BASE_URL ?>/image/favicon.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/css/layout-aprovado.css?v=20260708">
<?php if (!empty($css)) : ?><link rel="stylesheet" href="<?= BASE_URL ?>/css/pages/<?= htmlspecialchars($css) ?>"><?php endif; ?>
</head>
<body>
<div class="sst-app">
  <aside class="sst-sidebar" id="sidebar">
    <div class="sst-brand"><div class="brand-shield"><i class="fa-solid fa-shield-halved"></i></div><div><strong>SST</strong><span>Gestão de SST</span></div></div>
    <div class="sst-user"><img src="https://i.pravatar.cc/80?img=12" alt=""><div><strong><?= htmlspecialchars($usuario) ?></strong><span>Técnico de Segurança</span></div></div>
    <nav class="sst-menu">
      <a class="<?= nav_active('dashboard',$rotaAtual) ?>" href="<?= BASE_URL ?>/dashboard"><i class="fa-solid fa-house"></i><span>Dashboard</span></a>
      <a class="<?= nav_active('agenda',$rotaAtual) ?>" href="<?= BASE_URL ?>/agenda"><i class="fa-regular fa-calendar"></i><span>Agenda</span></a>
      <a class="<?= nav_active('visitas',$rotaAtual) ?>" href="<?= BASE_URL ?>/visitas"><i class="fa-solid fa-route"></i><span>Visitas Técnicas</span></a>
      <a class="<?= nav_active('checklists',$rotaAtual) ?>" href="<?= BASE_URL ?>/checklists"><i class="fa-regular fa-square-check"></i><span>Check-lists</span></a>
      <a class="<?= nav_active('quantificacoes',$rotaAtual) ?>" href="<?= BASE_URL ?>/quantificacoes"><i class="fa-solid fa-chart-line"></i><span>Quantificações</span></a>
      <a class="<?= nav_active('nao_conformidades',$rotaAtual) ?>" href="<?= BASE_URL ?>/nao_conformidades"><i class="fa-solid fa-triangle-exclamation"></i><span>Não Conformidades</span></a>
      <a class="<?= nav_active('empresas',$rotaAtual) ?>" href="<?= BASE_URL ?>/empresas"><i class="fa-regular fa-building"></i><span>Empresas</span></a>
      <a class="<?= nav_active('hierarquias',$rotaAtual) ?>" href="<?= BASE_URL ?>/hierarquias"><i class="fa-solid fa-sitemap"></i><span>Hierarquia</span></a>
      <a class="<?= nav_active('riscos',$rotaAtual) ?>" href="<?= BASE_URL ?>/riscos"><i class="fa-solid fa-flask-vial"></i><span>Riscos (GHE)</span></a>
      <a class="<?= nav_active('equipamentos',$rotaAtual) ?>" href="<?= BASE_URL ?>/equipamentos"><i class="fa-solid fa-gauge-high"></i><span>Equipamentos</span></a>
      <a class="<?= nav_active('mensagens',$rotaAtual) ?>" href="<?= BASE_URL ?>/mensagens"><i class="fa-regular fa-envelope"></i><span>Mensagens</span><b>3</b></a>
      <a class="<?= nav_active('relatorios',$rotaAtual) ?>" href="<?= BASE_URL ?>/relatorios"><i class="fa-regular fa-file-lines"></i><span>Relatórios</span></a>
      <a class="<?= nav_active('usuarios',$rotaAtual) ?>" href="<?= BASE_URL ?>/usuarios"><i class="fa-regular fa-user"></i><span>Usuários</span></a>
      <a class="<?= nav_active('configuracoes',$rotaAtual) ?>" href="<?= BASE_URL ?>/configuracoes"><i class="fa-solid fa-gear"></i><span>Configurações</span></a>
    </nav>
    <a class="sst-logout" href="<?= BASE_URL ?>/logout"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Sair</span></a>
  </aside>
  <section class="sst-main">
    <header class="sst-topbar">
      <button class="icon-btn" id="btnToggleSidebar"><i class="fa-solid fa-bars"></i></button>
      <h1><?= htmlspecialchars($pageTitle) ?></h1>
      <div class="topbar-spacer"></div>
      <button class="icon-btn notify"><i class="fa-regular fa-bell"></i><span></span></button>
      <button class="icon-btn"><i class="fa-regular fa-message"></i></button>
    </header>
    <div class="sst-content">
