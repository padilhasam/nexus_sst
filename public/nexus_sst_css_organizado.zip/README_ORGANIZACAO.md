# CSS organizado — Nexus SST

## Estrutura ativa

```text
public/css/
├── app.css                 # arquivo global carregado no header
├── base/                   # variáveis e normalização
├── app/                    # estrutura global, tema e utilitários
├── layout/                 # sidebar, topbar, conteúdo e footer
├── components/             # botões, cards, tabelas, abas etc.
├── pages/                  # CSS específico de cada página
└── vendor/                 # bibliotecas externas
```

## Alteração no `header.php`

Remova:

```php
<link rel="stylesheet" href="<?= BASE_URL ?>/css/layout-aprovado.css?v=20260709">
```

Use:

```php
<link rel="stylesheet" href="<?= BASE_URL ?>/css/app.css?v=<?= time() ?>">

<?php if (!empty($css)) : ?>
    <link rel="stylesheet"
          href="<?= BASE_URL ?>/css/pages/<?= htmlspecialchars($css) ?>?v=<?= time() ?>">
<?php endif; ?>
```

## CSS específico por página

Na Controller, envie:

```php
'css' => 'agenda.css',
```

ou, antes de incluir o header na view:

```php
$css = 'agenda.css';
```

## O que foi removido da estrutura ativa

- `layout-aprovado.css` — dividido em arquivos menores.
- arquivos CSS vazios — não tinham regras e só aumentavam a confusão.
- duplicações de `.sidebar` e `.sst-sidebar` — mantida apenas a estrutura usada pelo HTML atual (`.sst-sidebar`).
- duplicações antigas do Topbar — consolidado em `layout/topbar.css`.
- regras do menu sanfona que causavam deslocamento lateral — a animação agora atua somente na altura.

## Observação importante

Antes de substituir a pasta em produção, mantenha uma cópia da pasta CSS atual. O pacote foi organizado com base nas classes e arquivos enviados, preservando os CSS de páginas que continham regras.
